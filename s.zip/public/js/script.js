// 主题切换
document.querySelector('.theme-switcher').addEventListener('click', () => {
  document.documentElement.setAttribute('data-theme',
    document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark'
  );
  localStorage.setItem('theme', document.documentElement.getAttribute('data-theme'));
});

// 搜索功能
document.getElementById('searchBtn').addEventListener('click', performSearch);
document.getElementById('searchInput').addEventListener('keypress', (e) => {
  if (e.key === 'Enter') performSearch();
});

let searchTimeout;
document.getElementById('searchInput').addEventListener('input', (e) => {
  clearTimeout(searchTimeout);
  searchTimeout = setTimeout(() => {
    if (!e.target.value.trim()) {
      document.getElementById('results').innerHTML = '';
    }
  }, 300);
});

async function performSearch() {
  const searchTerm = document.getElementById('searchInput').value.trim();
  const response = await fetch(`/search?name=${encodeURIComponent(searchTerm)}`);
  const results = await response.json();

  const filteredResults = results.filter(item =>
      item.name.toLowerCase() === searchTerm.toLowerCase()
  );

  const resultsContainer = document.getElementById('results');
  resultsContainer.innerHTML = filteredResults.map(user => `
    <div class="acrylic result-item" onclick="location.href='/details/${user.id}'">
      <h3>${user.name}</h3>
      <p>${user.class}</p>
    </div>
  `).join('');

  if (filteredResults.length === 0 && searchTerm) {
    resultsContainer.innerHTML = `
      <div class="acrylic result-item">
        <p>未找到匹配的同学</p>
      </div>
    `;
  }
}

// 初始化主题
const savedTheme = localStorage.getItem('theme') || 'light';
document.documentElement.setAttribute('data-theme', savedTheme);
// 在原有代码后新增以下内容

// 详情页加载逻辑
if (document.getElementById('name')) {
  async function loadProfile() {
    const id = parseInt(location.pathname.split('/').pop());
    const response = await fetch(`/getUser/${id}`);
    const user = await response.json();

    if (user) {
      document.getElementById('name').textContent = user.name;
      document.getElementById('dob').textContent = user.dob;
      document.getElementById('class').textContent = user.class;
      document.getElementById('position').textContent = user.position;
      document.getElementById('bio').textContent = user.bio;
      
      // 自动调整布局
      requestAnimationFrame(() => {
        document.querySelectorAll('.profile-section').forEach(section => {
          section.style.minHeight = `${section.scrollHeight + 20}px`;
        });
      });
    }
  }
  loadProfile();
}
