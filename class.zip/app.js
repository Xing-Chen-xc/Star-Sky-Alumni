//npm install express body-parser
const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// 数据存储
const DATA_FILE = path.join(__dirname, 'classmates.json');

// 初始化数据
if (!fs.existsSync(DATA_FILE)) {
  fs.writeFileSync(DATA_FILE, JSON.stringify([
    {
      "id": 1,
      "name": "张三",
      "dob": "2002-03-15",
      "class": "初一(1)班",
      "position": "班长 语文课代表",
      "bio": "nb，非常nb"
    }
  ]));
}

// 路由
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'index.html'));
});

app.get('/search', (req, res) => {
  const { name } = req.query;
  const data = JSON.parse(fs.readFileSync(DATA_FILE));
  res.json(data.filter(item => item.name.includes(name)));
});

app.get('/details/:id', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'details.html'));
});

// 在原有路由后新增详情数据接口
app.get('/getUser/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const data = JSON.parse(fs.readFileSync(DATA_FILE));
  const user = data.find(item => item.id === id);
  res.json(user || {});
});


app.listen(8080, () => {
  console.log('http://localhost:8080');
  console.log('hi?');
});
